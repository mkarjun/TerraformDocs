exports.handler = async (event) => {
    try {
        console.log('lambda started running ***********************************************')
        console.log('lambda execution completed *******************************************')
    } catch (e) {
        console.log(e)
        console.log('**********************************************************************')
    }
};